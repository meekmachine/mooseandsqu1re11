import os

d1 = 'client'
d2 = 'counselor'
# iterate over files in
# that directory
for filename in sorted(os.listdir(d1)):
    fn = os.path.join(d1, filename)
    # checking if it is a file
    if os.path.isfile(fn):
        with open(fn) as f:
            lines = f.readlines()
        f.close()
    print(file)